from __future__ import print_function
import click

message = click.edit()
print(message, end="")
