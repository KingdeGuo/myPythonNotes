while True:
    user_input = raw_input('>')
    print(user_input)
