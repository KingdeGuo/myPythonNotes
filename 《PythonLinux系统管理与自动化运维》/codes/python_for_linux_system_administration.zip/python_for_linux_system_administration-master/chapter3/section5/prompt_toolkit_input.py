from prompt_toolkit import prompt

while True:
    user_input = prompt('>')
    print(user_input)
