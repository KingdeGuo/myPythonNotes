import sys

sys.stdout.write('hello')
sys.stderr.write('world')
