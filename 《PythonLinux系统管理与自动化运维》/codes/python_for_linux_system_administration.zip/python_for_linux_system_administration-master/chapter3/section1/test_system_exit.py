import sys

raise SystemExit('error message')
