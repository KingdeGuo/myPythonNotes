from __future__ import print_function
import sys

def get_content():
    return sys.stdin.readlines()

print(get_content())
