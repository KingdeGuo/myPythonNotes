class Person(object):
    def __init__(self, name, age):
        self.name = name
        self.age = age

jason = Person('Jason Statham', 50)
jason.age = -1
